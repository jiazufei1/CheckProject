//
//  ParsingImplementation.swift
//  SMCheckProject
//
//  Created by daiming on 2017/2/28.
//  Copyright © 2017年 Starming. All rights reserved.
//

import Cocoa

class ParsingImplementation: NSObject {
    class func parsing(line:String, inObject:Object) {
//        let aline = line.replacingOccurrences(of: Sb.atImplementation, with: "")
//        let tokens = ParsingBase.createOCLines(content: aline);
//        for tk in tokens {
//            
//        }
    }

}
